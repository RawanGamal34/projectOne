import React from 'react'
import { Link } from "react-router-dom";
import './headerall.css'

function HeaderAll() {
    return (
        <>
            {/*start nav bar */}
            <nav className="row navALL" id="home">
                <div className="col-lg-6 p-3">
                    <div className="logo d-flex align-items-end">
                        <img src="images/logo.png" alt="logo" />
                        <h5 className="text-dark">
                            {" "}
                            <b>FindHouse</b>
                        </h5>
                    </div>
                </div>
                <div className="col-lg-6 p-3">
                    <ul className="d-flex justify-content-end">
                        <li>
                            <Link to="/">Home</Link>
                        </li>
                        <li>
                            <Link to="/properties">Property</Link>
                        </li>
                        <li>
                            <Link to="/services">Services</Link>
                        </li>
                        <li>
                            <Link to="/blog">Blog</Link>
                        </li>
                        <li>
                            <Link to="/about">About Us</Link>
                        </li>
                        <li>
                            <Link to="/contact">Contact Us</Link>
                        </li>
                    </ul>

                </div>
            </nav>
            {/* nav responsive */}
            <div className="row menue" id="home">
                <nav className="navbar fixed-top">
                    <div className="container-fluid">
                        <Link className="navbar-brand" to=" /">
                            <div className="logo d-flex align-items-end">
                                <img src="images/logo.png" alt="" />
                                <h5 className="text-white">FindHouse</h5>
                            </div>
                        </Link>
                        <button
                            className="navbar-toggler"
                            type="button"
                            data-bs-toggle="offcanvas"
                            data-bs-target="#offcanvasNavbar"
                            aria-controls="offcanvasNavbar"
                            aria-label="Toggle navigation"
                        >
                            <span className="navbar-toggler-icon" />
                        </button>
                        <div
                            className="offcanvas offcanvas-end"
                            tabIndex={-1}
                            id="offcanvasNavbar"
                            aria-labelledby="offcanvasNavbarLabel"
                        >
                            <div className="offcanvas-header">
                                <h5 className="offcanvas-title" id="offcanvasNavbarLabel">
                                    FindHouse Menue
                                </h5>
                                <button
                                    type="button"
                                    className="btn-close"
                                    data-bs-dismiss="offcanvas"
                                    aria-label="Close"
                                />
                            </div>
                            <div className="offcanvas-body">
                                <ul className="navbar-nav justify-content-end flex-grow-1 pe-3">
                                    <li className="nav-item">
                                        <Link
                                            className="nav-link active"
                                            to="/"
                                        >
                                            Home
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/properties">
                                            Property
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/services">
                                            Services
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/blog">
                                            Blog
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/about">
                                            About Us
                                        </Link>
                                    </li>
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/contact">
                                            Contact US
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
            {/* end of nav bar */}
        </>

    )
}

export default HeaderAll