import React from "react";

import "./general.css"
function Footer() {
  return (
    <>
      {/* footer */}
      <footer className="container-fluid">

        <div className="row red-bar">
          <div className="col">
            <div className="container">
              <div className="row ">
                <div className="col-lg-8">
                  <h4 className="text-white mt-5"> Become a Real Estate Agent</h4>
                  <p className="text-white">
                    We only work with the best companies around the globe
                  </p>
                </div>
                <div className="col-lg-4 mt-5 mb-5">
                  <button className="btn text-white">Register Now</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col">
            <div className="container">
              <div className="row mt-5 mb-5">
                <div className="col-lg-3">
                  <h5 className="text-white">About Site</h5>
                  <p className="text-white-50">
                    We're remagining how you buy , sell and rent . <br /> It's now
                    waseier to get into a place you love. So let's do this,
                    together.{" "}
                  </p>
                </div>
                <div className="col-lg-3">
                  <h5 className="text-white">Quick Links </h5>
                  <ul className="text-white-50 list-unstyled">
                    <li>
                      <a
                        className="text-white-50 text-decoration-none"
                        href="about-us-8.html"
                      >
                        About Us
                      </a>
                    </li>
                    <li> Terms &amp; Conditions</li>
                    <li>User's Guide</li>
                    <li>Support Center</li>
                    <li>Press Info</li>
                  </ul>
                </div>
                <div className="col-lg-3">
                  <h5 className="text-white">Contact US</h5>
                  <ul className="text-white-50 list-unstyled">
                    <li>info@findhouse.com</li>
                    <li> Collins Street West. Victoria</li>
                    <li>8007,Australia</li>
                    <li>+1 246-345-0699</li>
                    <li>+1 246-345-0695</li>
                  </ul>
                </div>
                <div className="col-lg-3">
                  <h5 className="text-white ">Follow Us</h5>
                  <div className="d-flex ">
                    <i className="fa-brands fa-facebook-f text-white-50 p-2" />
                    <i className="fa-brands fa-twitter text-white-50 p-2" />
                    <i className="fa-brands fa-instagram text-white-50 p-2" />
                    <i className="fa-brands fa-pinterest text-white-50 p-2" />
                  </div>
                  <h5 className="text-white mt-4">Subscribe</h5>
                  <form action="">
                    <input
                      type="email"
                      placeholder="Your Email"
                      className="p-2 text-dark"
                    />
                    <button className="cicleBtn ">
                      <i className="fa-solid fa-chevron-right text-white" />
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row dark-footer ">
          <div className="col">
            <div className="container">
              <div className="row">
                <div className="col-lg-6">
                  <ul className="text-white-50 d-flex list-unstyled justify-content-between">
                    <li>Home</li>
                    <li>Listing</li>
                    <li>Property</li>
                    <li> About Us </li>
                    <li> Blog</li>
                    <li>contact</li>
                  </ul>
                </div>
                <div className="col-lg-6 d-flex justify-content-end">
                  <p className="text-white-50">
                    {" "}
                    2024 by company . All rights reseved
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
      <a
        href="#home"
        className="up d-flex justify-content-center align-items-center text-decoration-none text-white-50"
      >UP
        <i className="fa-solid fa-arrow-up text-white" />
      </a>
    </>
  );
}

export default Footer;
