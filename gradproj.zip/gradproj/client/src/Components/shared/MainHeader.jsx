import React from "react";
import Headerjs from "./Headerjs";
import HeaderAll from "./HeaderAll";
import { useLocation } from "react-router-dom";
import "./general.css";

function MainHeader() {
  const location = useLocation();
  const isHome = location.pathname === "/"; // Determine if current route is home

  return isHome ? (
    <>
      <Headerjs />
    </>
  ) : (
    <>
      <HeaderAll />
    </>
  );
}

export default MainHeader;
