import React from 'react'

function Services() {
  return (
    <div>
       <p>Services</p>
    </div>
  )
}

export default Services
