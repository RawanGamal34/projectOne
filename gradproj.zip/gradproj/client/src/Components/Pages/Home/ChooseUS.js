import React from 'react'

function ChooseUS() {
    return (
        <>
            {/* Why choose Us */}
            <section className="chooseUS">
                <div className="container-fluid">
                    <div className="row text-center mt-5">
                        <h2 className="text-dark mt-5">Why Choose Us?</h2>
                        <p className="text-body-secondary">
                            We provide full services on every step.
                        </p>
                    </div>
                    <div className="row">
                        <div className="col">
                            <div className="container">
                                <div className="row">
                                    <div className="col-lg-4">
                                        <div className="card">
                                            <div className="circle d-flex justify-content-center align-items-center">
                                                <i className="fa-solid fa-hands-clapping" />
                                            </div>
                                            <div className="card-body text-center">
                                                <h5 className="text-dark-emphasis">Trusted By Thousands</h5>
                                                <p className="text-body-secondary">
                                                    Aliquam dictum elit vitae mauris facilisis at dictum urna
                                                    dignissim donec vel lectus vel felis.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-lg-4">
                                        <div className="card">
                                            <div className="circle d-flex justify-content-center align-items-center">
                                                <i className="fa-solid fa-house" />
                                            </div>
                                            <div className="card-body text-center">
                                                <h5 className="text-dark-emphasis">
                                                    Wide Renge Of Properties
                                                </h5>
                                                <p className="text-body-secondary">
                                                    Aliquam dictum elit vitae mauris facilisis at dictum urna
                                                    dignissim donec vel lectus vel felis.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-lg-4">
                                        <div className="card">
                                            <div className="circle d-flex justify-content-center align-items-center">
                                                <i className="fa-solid fa-calculator" />
                                            </div>
                                            <div className="card-body text-center">
                                                <h5 className="text-dark-emphasis">Financing Made Easy</h5>
                                                <p className="text-body-secondary">
                                                    Aliquam dictum elit vitae mauris facilisis at dictum urna
                                                    dignissim donec vel lectus vel felis.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="row text-center mt-5">
                                    <h2 className="text-dark mt-5">Article &amp; Tips</h2>
                                    <p className="text-body-secondary">
                                        Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                                        Laudantium velit atque
                                    </p>
                                </div>
                                <div className="row">
                                    <div className="col-lg-4">
                                        <div className="card">
                                            <div className="card-body">
                                                <div className="images">
                                                    {" "}
                                                    <img src="images/vue-de-la-piscine.jpg" alt="" />
                                                </div>
                                                <h6>bussenies</h6>
                                                <p>
                                                    <b>Skills That You Can Learn in The Real Estate Market</b>
                                                </p>
                                            </div>
                                            <div className="d-flex justify-content-between card-footer text-body-secondary">
                                                <div className="d-flex ">
                                                    <p>Ali Tufan</p>
                                                </div>
                                                <p>7 Augest 2022</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-lg-4">
                                        <div className="card">
                                            <div className="card-body">
                                                <div className="images">
                                                    {" "}
                                                    <img src="images/images.jfif" alt="" />
                                                </div>
                                                <h6>Construction</h6>
                                                <p>
                                                    <b>
                                                        Bedroom Colors You will Never this <br /> Regret
                                                    </b>
                                                </p>
                                            </div>
                                            <div className="d-flex justify-content-between card-footer text-body-secondary">
                                                <div className="d-flex ">
                                                    <p>Ali Tufan</p>
                                                </div>
                                                <p>7 Augest 2022</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-lg-4">
                                        <div className="card">
                                            <div className="card-body">
                                                <div className="images">
                                                    {" "}
                                                    <img src="images/download.jfif" alt="" />
                                                </div>
                                                <h6>bussenies</h6>
                                                <p>
                                                    <b>5 Essential Steps for Buying everyone Investment</b>
                                                </p>
                                            </div>
                                            <div className="d-flex justify-content-between card-footer text-body-secondary">
                                                <div className="d-flex ">
                                                    <p>Ali Tufan</p>
                                                </div>
                                                <p>7 Augest 2022</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>

    )
}

export default ChooseUS