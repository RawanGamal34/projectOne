import React from 'react'
import './style.css'
import Slider from './Slider'
import ChooseUS from './ChooseUS'
import Partners from './Partners'
function HeroSection() {

    return (
        <>
            <Slider />
            <ChooseUS />
            <Partners />
        </>
    )
}

export default HeroSection
