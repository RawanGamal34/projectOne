import React from 'react'

function Partners() {
    return (
        <>
            {/* partners */}
            <section className=" partners">
                <div className="container-fluid">
                    <div className="row text-center mt-3">
                        <h2 className="text-dark mt-5">Our partners</h2>
                        <p className="text-body-secondary">
                            We only work with the best companies around the globe
                        </p>
                    </div>
                    <div className="d-flex justify-content-evenly mb-5">
                        <img src="./_assets_images_partners_1.png" alt="partner company" />
                        <img src="./_assets_images_partners_2.png" alt="partner company" />
                        <img src="./_assets_images_partners_3.png" alt="partner company" />
                        <img src="./_assets_images_partners_4.png" alt="partner company" />
                        <img src="./_assets_images_partners_5.png" alt="partner company" />
                    </div>
                </div>
            </section>
        </>

    )
}

export default Partners