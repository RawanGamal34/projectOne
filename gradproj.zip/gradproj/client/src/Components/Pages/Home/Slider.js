import React from 'react';

// Define the Header component
function Slider() {
    return (
        <>
            {/* slider */}
            <section className="slider container-fluid ">
                <div className="row">
                    <div className="col">
                        <div className="container">
                            <div className="row text-center">
                                <h2 className="text-dark mt-5">Featured Properties</h2>
                                <p className="text-body-secondary">
                                    HandPicked properities by out team.
                                </p>
                            </div>
                            <div className="cards row">
                                <div className=" col-lg-4">
                                    <div className="card">
                                        <div className="card-body">
                                            <div className="images">
                                                <div className="d-flex btns">
                                                    <button className="featturedBtn">Freatured</button>
                                                    <button className="stateBtn">For Sale</button>
                                                </div>
                                                <img src="images/vue-de-la-piscine.jpg" alt="" />
                                                <div className="price d-flex justify-content-between">
                                                    <div className="text-white ">
                                                        {" "}
                                                        $13000/ <sub>mo</sub>
                                                    </div>
                                                    <div className="d-flex">
                                                        <div className="blackBox">
                                                            <i className="fa-solid fa-arrow-right-arrow-left" />
                                                        </div>
                                                        <div className="blackBox">
                                                            <i className="fa-regular fa-heart" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <h6>Apartment</h6>
                                            <p>
                                                <b>Luxury Family Home</b>
                                            </p>
                                            <p>
                                                <i className="fa-solid fa-location-dot text-body-secondary" />{" "}
                                                1421 San Pedro St.Los Angles, CA 900015{" "}
                                            </p>
                                            <ul className="d-flex list-unstyled text-body-secondary ">
                                                <li>Bed:1 </li>
                                                <li>baths:1 </li>
                                                <li>sqFt:8280</li>
                                            </ul>
                                        </div>
                                        <div className="d-flex justify-content-between card-footer text-body-secondary">
                                            <div className="d-flex ">
                                                <p>Ali Tufan</p>
                                            </div>
                                            <p>1 Year ago</p>
                                        </div>
                                    </div>
                                </div>
                                <div className=" col-lg-4">
                                    <div className="card">
                                        <div className="card-body">
                                            <div className="images">
                                                <div className="d-flex btns">
                                                    <button className="featturedBtn">Freatured</button>
                                                    <button className="stateBtn">For Rent</button>
                                                </div>
                                                <img src="images/vue-de-la-piscine.jpg" alt="" />
                                                <div className="price d-flex justify-content-between">
                                                    <div className="text-white ">
                                                        {" "}
                                                        $14000/ <sub>mo</sub>
                                                    </div>
                                                    <div className="d-flex">
                                                        <div className="blackBox">
                                                            <i className="fa-solid fa-arrow-right-arrow-left" />
                                                        </div>
                                                        <div className="blackBox">
                                                            <i className="fa-regular fa-heart" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <h6>Apartment</h6>
                                            <p>
                                                <b>Luxury Family Home</b>
                                            </p>
                                            <p>
                                                <i className="fa-solid fa-location-dot text-body-secondary" />{" "}
                                                1421 San Pedro St.Los Angles, CA 900015{" "}
                                            </p>
                                            <ul className="d-flex list-unstyled text-body-secondary ">
                                                <li>Bed:2 </li>
                                                <li>baths:2 </li>
                                                <li>sqFt:5280</li>
                                            </ul>
                                        </div>
                                        <div className="d-flex justify-content-between card-footer text-body-secondary">
                                            <div className="d-flex ">
                                                <p>Ali Tufan</p>
                                            </div>
                                            <p>1 Year ago</p>
                                        </div>
                                    </div>
                                </div>
                                <div className=" col-lg-4">
                                    <div className="card">
                                        <div className="card-body">
                                            <div className="images">
                                                <div className="d-flex btns">
                                                    <button className="featturedBtn">Freatured</button>
                                                    <button className="stateBtn">For Rent</button>
                                                </div>
                                                <img src="images/vue-de-la-piscine.jpg" alt="" />
                                                <div className="price d-flex justify-content-between">
                                                    <div className="text-white ">
                                                        {" "}
                                                        $13000/ <sub>mo</sub>
                                                    </div>
                                                    <div className="d-flex">
                                                        <div className="blackBox">
                                                            <i className="fa-solid fa-arrow-right-arrow-left" />
                                                        </div>
                                                        <div className="blackBox">
                                                            <i className="fa-regular fa-heart" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <h6>Apartment</h6>
                                            <p>
                                                <b>Luxury Family Home</b>
                                            </p>
                                            <p>
                                                <i className="fa-solid fa-location-dot text-body-secondary" />{" "}
                                                1421 San Pedro St.Los Angles, CA 900015{" "}
                                            </p>
                                            <ul className="d-flex list-unstyled text-body-secondary ">
                                                <li>Bed:3 </li>
                                                <li>baths:3 </li>
                                                <li>sqFt:3280</li>
                                            </ul>
                                        </div>
                                        <div className="d-flex justify-content-between card-footer text-body-secondary">
                                            <div className="d-flex ">
                                                <p>Ali Tufan</p>
                                            </div>
                                            <p>1 Year ago</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="dots row mb-5">
                                <div className="col text-center">
                                    <span className="dot" />
                                    <span className="dot" />
                                    <span className="dot" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            {/* cities */}
            <section className="cities container">
                <div className="row text-center">
                    <h2 className="text-dark mt-5">Find Properties in These Cities</h2>
                    <p className="text-body-secondary">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    </p>
                </div>
                <div className="row">
                    <div className="col-lg-4 miami position-relative">
                        <div className="images pt-3">
                            <img src="images/miami.jfif" alt="" />
                        </div>
                        <p className="text-white cityName">
                            <b>miami</b>
                            <br /> 24 Properties
                        </p>
                    </div>
                    <div className="col-lg-8 losAngeles position-relative">
                        <div className="images pt-3">
                            <img src="images/losAngeles.jfif" alt="" />
                        </div>
                        <p className="text-white cityName">
                            <b> los Angeles</b>
                            <br /> 18 Properties
                        </p>
                    </div>
                </div>
                <div className="row">
                    <div className="col-lg-8 NewYork position-relative">
                        <div className="images pt-3">
                            <img src="images/NewYork.jfif" alt="" />
                        </div>
                        <p className="text-white cityName">
                            {" "}
                            <b>New York</b>
                            <br /> 89 Properties
                        </p>
                    </div>
                    <div className="col-lg-4 Florida position-relative">
                        <div className="images pt-3">
                            <img src="images/florida.jfif" alt="" />
                        </div>
                        <p className="text-white cityName">
                            <b> Florida</b>
                            <br /> 47 Properties
                        </p>
                    </div>
                </div>
            </section>
        </>

    );
}

export default Slider;