import React from 'react'
import './styles-contactus.css'
function Contact() {
  return (
    <>
      {/* Page Header */}
      <section className="page-header text-center">
        <div className="container">
          <h1>Contact Us</h1>
          <p>
            <a href=" ">Home</a> / Contact
          </p>
        </div>
      </section>
      {/* Contact Form and Details */}
      <section className="contact-section container py-5">
        <div className="row">
          {/* Contact Form */}
          <div className="col-lg-7 mb-4">
            <h3 className="mb-4">Send Us An Email</h3>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. In gravida
              quis libero eleifend ornare. Maecenas mattis enim at arcu feugiat,
              sit amet blandit nisi iaculis.
            </p>
            <form action="#" method="POST">
              <div className="form-row">
                <div className="col-md-6 mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Name"
                    required
                  />
                </div>
                <div className="col-md-6 mb-3">
                  <input
                    type="email"
                    className="form-control"
                    placeholder="Email"
                    required
                  />
                </div>
              </div>
              <div className="form-row">
                <div className="col-md-6 mb-3">
                  <input
                    type="tel"
                    minLength={11}
                    maxLength={11}
                    className="form-control"
                    placeholder="Phone"
                    required
                  />
                </div>
                <div className="col-md-6 mb-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Subject"
                    required
                  />
                </div>
              </div>
              <div className="form-group">
                <textarea
                  className="form-control"
                  rows={5}
                  placeholder="Your Message"
                  required
                  defaultValue={""}
                />
              </div>
              <button type="submit" className="btn btn-danger">
                Send Message
              </button>
            </form>
          </div>
          {/* Contact Information */}
          <div className="col-lg-5">
            <div className="contact-info bg-light p-4 rounded">
              <h3 className="mb-4">Contact Us</h3>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. In
                gravida quis libero eleifend ornare.
              </p>
              <ul className="list-unstyled">
                <li>
                  <strong>Address:</strong> 2301 Ravenswood Rd Madison, WI 53711
                </li>
                <li>
                  <strong>Phone:</strong> (315) 905-2321
                </li>
                <li>
                  <strong>Email:</strong> info@findhouse.com
                </li>
                <li>
                  <strong>Skype:</strong> findhouse
                </li>
              </ul>
              <h5>Follow Us</h5>
              <div className="social-icons mt-3">
                <a href=" " className="text-dark mr-3">
                  <i className="fa-brands fa-facebook-f" />
                </a>
                <a href=" " className="text-dark mr-3">
                  <i className="fa-brands fa-twitter" />
                </a>
                <a href=" " className="text-dark mr-3">
                  <i className="fa-brands fa-instagram" />
                </a>
                <a href=" " className="text-dark">
                  <i className="fa-brands fa-pinterest" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Map */}
      <section className="map-section">
        <div className="container">
          <div className="embed-responsive embed-responsive-16by9">
            {/* <iframe
                                className="embed-responsive-item"
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.2099672819413!2d-122.41941638468223!3d37.77492927975878!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858064c2b8a7df%3A0x7cb7e7b9ae5b8a6d!2sSan%20Francisco%2C%20CA!5e0!3m2!1sen!2sus!4v1596846955235!5m2!1sen!2sus"
                                allowFullScreen=""
                            /> */}
          </div>
        </div>
      </section>




    </>
  )
}

export default Contact
