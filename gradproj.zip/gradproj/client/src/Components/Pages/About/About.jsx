import React from 'react'

function About() {
  return (
    <div>
      <h1>sunt aut facere repellat provident occaecati excepturi optio reprehenderit</h1>
      <p>quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto</p>
    </div>
  )
}

export default About
